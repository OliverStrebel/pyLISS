import json

import numpy as np
import numpy.random as npr

from liss_runner.data import Data
from liss_runner.constants import Constants as C

from liss_core.facade import Facade
from liss_core.parameters import Parameters
from liss_core.stepresult import StepResult

from liss_core.functions.cubic2d import Cubic2D
from liss_core.functions.cubic3d import Cubic3D
from liss_core.functions.cubic4d import Cubic4D
from liss_core.functions.nonestimable import Nonestimable
from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction

from evaluation_of_experimental_data.experimentaldata import ExperimentalData

class AlgorithmCaller:
    def __init__(_, d: ExperimentalData):
        _.d = d
        _.cfg = _.d.jsonConfiguration
        _.sigmaSteps = _.cfg[C.sigmaSteps]
        _.sigmaStart = _.cfg[C.sigmaStart]
        _.sigmaDelta = _.cfg[C.sigmaDelta]
        _.jsonResults = {C.CONFIGURATION: d.jsonConfiguration}
        _.jsonResults[C.algos[0]] = {}


    def runEstimation(_):
        print('Data: ' + _.d.odeName) 
        liss = Facade(_._getODE(), _._getParameters())
        mode = C.algos[0]
        print( '    ' + mode)
        res = liss.estimateDifEf(_.d.odeData, _.d.t)
        _._storeInJsonResults(mode, res)
        
        return _.jsonResults


######################################################################################################
#private helpers for initialization
    def _init(_):
        return _.cfg[C.sigmaSteps], _.cfg[C.sigmaStart], _.cfg[C.sigmaDelta], {}


    def _getParameters(_) -> Parameters:
        return Parameters(_.cfg[C.sigmaScale]
                          , _.cfg[C.sampleSize]
                          , _.cfg[C.sampleCount]
                          , _.cfg[C.tangentRegressionSize])


    def _getODE(_) -> list[PolynomEstimationFunction]:
        if (_.cfg[C.estimationFunction] == C.Cubic2D): return [Cubic2D(), Cubic2D()]
        elif (_.cfg[C.estimationFunction] == C.Cubic3D): return [Cubic3D(), Cubic3D(), Cubic3D()]
        elif (_.cfg[C.estimationFunction] == C.Driven3D): return [Cubic3D(), Cubic3D(), Nonestimable()]
        elif (_.cfg[C.estimationFunction] == C.Cubic4D): return [Cubic4D(), Cubic4D(), Cubic4D(), Cubic4D()]
        else:
            msg = "Invalid parametrisation of Configuration.estimationFunction"
            print(msg)
            raise Exception(msg)
            


######################################################################################################
#private helper for coversion to JSON
    def _storeInJsonResults(_, algo: str, res: list[StepResult]):
        sr_all = {}
        for i in range(len(res)):
            sr = {}
            if len(res[i]) > 0:
                sr[C.means] = res[i][0].means
                sr[C.stddevs] = res[i][0].stddevs
                sr[C.parameterNumbers] = res[i][0].parameterNumbers
                sr[C.successfulSampleCount] = res[i][0].successfulSampleCount
                
            sr_all[i] = sr
            
        _.jsonResults[algo] = sr_all   
