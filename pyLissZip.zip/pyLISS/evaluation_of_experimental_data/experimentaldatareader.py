import csv
import json
import numpy as np
import os

import liss_runner.data
from evaluation_of_experimental_data.experimentaldata import ExperimentalData


def readAll(fName):
    raw = _readRawData(fName)
    t = raw[:,0]
    return ExperimentalData(_getODEName(fName)
                , t
                , _removeColumn(raw)
                , _readConfig(fName)
                , fName) 


######################################################################################################
#private helpers for data
def _readRawData(fileName):
    rawFile = open(fileName)
    raw = np.loadtxt(rawFile, delimiter=';', skiprows=3)#default: float
    rawFile.close()
    return raw


def _removeColumn(raw):
    j = raw[0,:].size
    return raw[:,1:j]


def _getODEName(fileName):
    theFile=os.path.basename(fileName)
    baseName, extension = os.path.splitext(theFile)
    return baseName


######################################################################################################
#private helpers for reference data
def _openFile(fileName):
    baseName, extension = os.path.splitext(fileName)
    refFileName = baseName + '.ref'
    return open(refFileName)


######################################################################################################
#private helpers for json configuration data
def _readConfig(fileName):
    baseName, extension = os.path.splitext(fileName)
    configFileName = baseName + '.json'
    configFile = open(configFileName)
    jsn = json.load(configFile)
    configFile.close()
    return jsn
