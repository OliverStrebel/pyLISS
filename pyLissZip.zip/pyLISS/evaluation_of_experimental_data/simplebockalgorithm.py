import numpy

from scipy.linalg import lstsq
from scipy import linalg

from liss_runner.constants import Constants as C

from evaluation_of_experimental_data.experimentaldata import ExperimentalData
from evaluation_of_experimental_data.ImplicitEulerIntegrator2D3rdDegree import ImplicitEulerIntegrator2D3rdDegree
from evaluation_of_experimental_data.ImplicitEulerIntegrator2D3rdDegree import ImplicitEulerIntegrator2D3rdDegree

from liss_runner.data import Data

# This is a simple version of Bocks algorithm. See:
#    Baake E., Baake M., Bock H., Briggs K.: Fitting ordinary differential
#    equations to chaotic data.
#    Physical Review A (1992).
#    http://dx.doi.org/10.1103/PhysRevA.45.5524
# Only one curve segment for the entire data set is used.
# The ODE-model and the start parameters are those obtained by the preprocessing method.

# The Gauss-Newton-Algorithm is used

# Automatic differentiation of algorithms is avoided for simplicity and
# due to the zeroth rule of automatic differentiation of Griewank:
# "Finite differences work too"

# Uses error oriented Newton iteration
#    See: P. Deuflhard, Newton Methods for Nonlinear Problems (2nd printing)
#                       Heidelberg: Springer Series in Computational Mathematics
#                       Vol. 35 (2006)
# The reason for this choice is that the model data can be
# quite far away from the experimental data, so that residual-oriented Newton
# method might have large errors

class SimpleBockAlgorithm:
    def __init__(_
                 , data: ExperimentalData
                 , modelLissResult: dict
                 , interSteps = 0):
        _.data = data
        _.modelLissResult = modelLissResult
        _.interSteps = interSteps
        _.minIncrementNorm = 1.0E-010
        _.maxIter = 1000
        _.numRowsNewton = 200
        _.epsGradient = 0.00001 #works better than Dennis-Schnabel macheps for optimization
        _.unUsed = True
        _.vals, _.nums = _._par()
        print(_.nums)
        

#############################################################################
# private helpers of the constructor 
    def _par(_):
        vals = []
        nums = []
        for iComp in range(0, len(_.modelLissResult[C.DIF_EF])):
            vals.append(_.modelLissResult[C.DIF_EF][iComp][C.means])
            nums.append(_.modelLissResult[C.DIF_EF][iComp][C.parameterNumbers])
        return  vals,  nums


#############################################################################
# public
    def run(_):
        xl = _.vals.copy()
        if (_.unUsed): xl = _._newtonIteration(xl)
        else: 
            msg = "Create new instance of SimpleBockAlgorithm"
            print(msg)
            raise Exception(msg)
        _.unUsed = False
        return _._integrate(xl)


#############################################################################
# private
    def _newtonIteration(_, xl: list):
        print("Start parameters before Bock Algo: " + str(xl))
        inc = 1.0
        it = 0
        x = _._getVectorFromList(xl)
        while (inc > _.minIncrementNorm and it < _.maxIter):
            A, b = _._setRegressionEquation(x)
            d, res, r, s = lstsq(A, b, lapack_driver='gelsy')#gelsy getestet
            inc  = numpy.linalg.norm(d)
            print("Increment Bock algorithm: " + str(inc))
            x = numpy.add(x, d)
            it = it+1
        _._setListFromVector(xl, x)
        print("Refined Parameters after Bock Algo: " + str(xl))
        return xl


    def _getVectorFromList(_,xl: list):
        iSize = 0
        for i in range(0, len(xl)):
            for j in range(0, len(xl[i])): iSize = iSize+1
        x = numpy.zeros(iSize)
        iPos = 0
        for i in range(0, len(xl)):
            for j in range(0, len(xl[i])):
                x[iPos] = xl[i][j]
                iPos = iPos+1
            
        return x
       

    def _setListFromVector(_,xl: list, x: numpy.array):
        iPos = 0
        for i in range(0, len(xl)):
            for j in range(0, len(xl[i])):
                xl[i][j] = x[iPos]
                iPos = iPos+1

        
    #Scaled Regression fuer AT*A
    def _setRegressionEquation(_, x: numpy.array):
        return _._get_A(x), _._get_b(x)


    def _get_b(_, x: numpy.array):
        b = numpy.zeros( len(_.data.odeData[0,:])*(_.numRowsNewton-1))
        intData = _._integrateVector(x)
        iStep = int(len(_.data.odeData[:,0])//(_.numRowsNewton+1))
        for i in range(0, len(b), len(intData[0,:])):
            iPos = int(int(1 + int(i//len(_.data.odeData[0,:])))*iStep) 
            for iComp in range(0, len(intData[0,:])):
                b[i+iComp] = _.data.odeData[iPos, iComp] - intData[iPos, iComp]
        return b


    def _get_A(_, x: numpy.array):
        iSize = len(x)
        A = numpy.zeros((int(len(_.data.odeData[0,:])*(_.numRowsNewton-1)), iSize))
        for j in range(0, iSize):
            h = _.epsGradient*x[j]
            x[j] = x[j] + h
            upper = _._integrateVector(x)
            x[j] = x[j] - 2.0*h
            lower = _._integrateVector(x)
            x[j] = x[j] + h
            iStep = int(len(_.data.odeData[:,0])//(_.numRowsNewton+1))
            for i in range(0, len(A[:,0]), len(_.data.odeData[0,:])):
                iPos = int(int(1 + int(i//len(_.data.odeData[0,:])))*iStep) 
                for iComp in range(0, len(_.data.odeData[0,:])):
                    A[i+iComp,j] = (upper[iPos,iComp] - lower[iPos,iComp])/(2.0*h) 
        return A
        

    def _integrateVector(_, x: numpy.array):
        xl = _.vals.copy()
        iPos = 0
        for i in range(0, len(xl)):
            for j in range(0, len(xl[i])):
                xl[i][j] = x[iPos]
                iPos = iPos+1
        return _._integrate(xl)


    def _integrate(_, xl: list):
        integrator = ImplicitEulerIntegrator2D3rdDegree(_.data.t, _.data.odeData[0,:], _.modelLissResult, 0, xl, _.nums )
        return integrator.run()

