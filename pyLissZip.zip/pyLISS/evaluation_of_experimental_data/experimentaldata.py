import numpy as np

class ExperimentalData:
    def __init__(self
                 , odeName: str
                 , t_: np.ndarray
                 , data: np.ndarray
                 , jsonConfig: dict
                 , fileName: str):
        self.odeName = odeName
        self.t = t_
        self.odeData = data
        self.jsonConfiguration = jsonConfig
        self.fileName = fileName

