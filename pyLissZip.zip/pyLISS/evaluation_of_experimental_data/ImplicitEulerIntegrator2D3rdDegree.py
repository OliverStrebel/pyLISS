import numpy

from liss_runner.constants import Constants as C

#quirky: pythan can simulate multiple constructors only
#by using optional arguments
#https://realpython.com/python-multiple-constructors/
class ImplicitEulerIntegrator2D3rdDegree:
    def __init__(_
                 , t: numpy.array
                 , startValues: numpy.array
                 , modelLissResult
                 , interSteps
                 , vals
                 , nums):
        _.t = t
        _.modelLissResult = modelLissResult
        _.interSteps = interSteps
        _.targetEuclideanDistance = 1.0E-014
        _.maxIter = 1000
        _.x = _._getResultArray(startValues)
        _.unUsed = True
        if ( len(vals) != 0 and len(nums) != 0):
            _.vals = vals
            _.nums = nums
        else: _.vals, _.nums = _._par()
        

        

#############################################################################
# private helpers of the constructor 
    def _getResultArray(_, startValues):
        x = numpy.zeros((len(_.t), len(startValues)))
        x[0,:] = startValues
        return x


    def _par(_):
        pars = []
        nums = []
        for iComp in range(0, len(_.modelLissResult[C.DIF_EF])):
            pars.append(_.modelLissResult[C.DIF_EF][iComp][C.means])
            nums.append(_.modelLissResult[C.DIF_EF][iComp][C.parameterNumbers])
        return pars, nums


#############################################################################
# public
    
    def run(_):
        if (_.unUsed):
            for i in range(1, len(_.t)):
                _._fixPointInteration(i)
        else:
            msg = "Create new instance of ImplicitEulerIntegrator2D3rdDegree"
            print(msg)
            raise Exception(msg)

        _.unUsed = False
        return _.x


    def _fixPointInteration(_, iPos: int):
        v, ov, nv = _._initFPIteration(iPos)
        iSize = len(_.x[0,:])
        dt = (_.t[iPos] - _.t[iPos-1])/(_.interSteps + 1.0)
        for iStep in range(0,_.interSteps +1):
            it = 0
            error = 1.0
            while ((error > _.targetEuclideanDistance) and (it < _.maxIter)):
                for i in range(0, iSize):
                    nv[i] = ov[i] + dt*_._f(v, _.vals[i], _.nums[i])
                error = numpy.linalg.norm(numpy.subtract(v, nv))
                for i in range(0, iSize): v[i] = nv[i]
                it = it+1
            for i in range(0, iSize): ov[i] = nv[i]

        for i in range(0, iSize): _.x[iPos, i] = nv[i]
            

    def _initFPIteration(_, iPos: int):
        return numpy.copy(_.x[iPos-1,:]), numpy.copy(_.x[iPos-1,:]), numpy.copy(_.x[iPos-1,:]) 
            

    def _f(_, v: numpy.array, pars : numpy.array, nums: numpy.array):
        res = 0.0
        for i in range(0, len(nums)):
            if (nums[i] == 0): res = res + pars[i]
            if (nums[i] == 1): res = res + pars[i]*v[0]
            if (nums[i] == 2): res = res + pars[i]*v[1]
            if (nums[i] == 3): res = res + pars[i]*pow(v[0], 2.0)
            if (nums[i] == 4): res = res + pars[i]*v[0]*v[1]
            if (nums[i] == 5): res = res + pars[i]*pow(v[1], 2.0)
            if (nums[i] == 6): res = res + pars[i]*pow(v[0], 3.0)
            if (nums[i] == 7): res = res + pars[i]*pow(v[0], 2.0)*v[1]
            if (nums[i] == 8): res = res + pars[i]*v[0]*pow(v[1], 2.0)
            if (nums[i] == 9): res = res + pars[i]*pow(v[1], 3.0)
                       
        return res 


    def _explicitEulerStep(_, iPos: int):
        v, ov, nv = _._initFPIteration(iPos)
        iSize = len(_.x[0,:])
        for i in range(0, iSize):
            nv[i] = ov[i] + (_.t[iPos] - _.t[iPos-1])*_._f(v, _.vals[i], _.nums[i])
            
        for i in range(0, iSize): _.x[iPos, i] = nv[i]

