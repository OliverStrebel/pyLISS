import json

import numpy as np
import numpy.random as npr

from liss_runner.data import Data
from liss_runner.constants import Constants as C

from liss_core.facade import Facade
from liss_core.parameters import Parameters
from liss_core.stepresult import StepResult

from liss_core.functions.cubic2d import Cubic2D
from liss_core.functions.cubic3d import Cubic3D
from liss_core.functions.cubic4d import Cubic4D
from liss_core.functions.nonestimable import Nonestimable
from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction

class AllAlgorithmsNoiseScan:
    def __init__(_, d: Data):
        _.d = d
        _.cfg = _.d.jsonConfiguration
        _.sigmaSteps = _.cfg[C.sigmaSteps]
        _.sigmaStart = _.cfg[C.sigmaStart]
        _.sigmaDelta = _.cfg[C.sigmaDelta]
        _.jsonResults = {C.REFERENCE_DATA: d.jsonReferenceData
                         , C.CONFIGURATION: d.jsonConfiguration}
        for i in range(0,len(C.algos)):
            _.jsonResults[C.algos[i]] = {}


    def runEstimations(_):
        print('ODE: ' + _.d.odeName) 
        for i in range(_.sigmaSteps):
            percentNoise = _.sigmaStart + _.sigmaDelta*i
            print( '  percent noise peak to peak: ' +str(round(percentNoise*100, 2)))
            noiseData = _._addNoise(_.d.odeData, percentNoise)
            _._runAllAgorithms(noiseData, percentNoise)
        
        return _.jsonResults


######################################################################################################
#private helpers for noise generation
    def _addNoise(_, odeData: np.ndarray, noiseLevel: float):
        npr.seed(45638427)
        nD = np.empty_like(odeData)
        sig = _._getNoiseLevels(odeData, noiseLevel)
        for j in range(len(nD[0,:])):
            nD[:,j] = odeData[:,j] + npr.normal(loc=0.0, scale=sig[j], size=len(nD[:,j]))
        return nD 


    def _getNoiseLevels(_, data, noiseLevel: float):
        dMax = np.empty([len(data[0,:])])
        dMin = np.empty([len(data[0,:])])
        for i in range(len(data[0,:])):
            dMax[i] = max(data[:,i])
            dMin[i] = min(data[:,i])
                        
        return noiseLevel*(dMax - dMin)


######################################################################################################
#private helper
    def _runAllAgorithms(_, noiseData: np.ndarray, percentNoise: float):
        liss = Facade(_._getODE(), _._getParameters())

        for i in range(0,len(C.algos)):
            mode = C.algos[i]
            print( '    ' + mode)
            if (mode == C.DIF_EF): res = liss.estimateDifEf(noiseData, _.d.t)
            if (mode == C.DIF_EN): res = liss.estimateDifEn(noiseData, _.d.t)
            if (mode == C.INT_EF): res = liss.estimateIntEf(noiseData, _.d.t)
            if (mode == C.INT_EN): res = liss.estimateIntEn(noiseData, _.d.t)
            _._storeInJsonResults(mode, res, percentNoise)
            _._doPrint(res)



######################################################################################################
#private helpers for initialization
    def _init(_):
        return _.cfg[C.sigmaSteps], _.cfg[C.sigmaStart], _.cfg[C.sigmaDelta], {}


    def _getParameters(_) -> Parameters:
        return Parameters(_.cfg[C.sigmaScale]
                          , _.cfg[C.sampleSize]
                          , _.cfg[C.sampleCount]
                          , _.cfg[C.tangentRegressionSize])


    def _getODE(_) -> list[PolynomEstimationFunction]:
        if (_.cfg[C.estimationFunction] == C.Cubic2D): return [Cubic2D(), Cubic2D()]
        elif (_.cfg[C.estimationFunction] == C.Cubic3D): return [Cubic3D(), Cubic3D(), Cubic3D()]
        elif (_.cfg[C.estimationFunction] == C.Driven3D): return [Cubic3D(), Cubic3D(), Nonestimable()]
        elif (_.cfg[C.estimationFunction] == C.Cubic4D): return [Cubic4D(), Cubic4D(), Cubic4D(), Cubic4D()]
        else:
            msg = "Invalid parametrisation of Configuration.estimationFunction"
            print(msg)
            raise Exception(msg)
            


######################################################################################################
#private helper for logging
    def _doPrint(_, res: list):
        for iComp in range(len(res)):
            if len(res[iComp]) > 0:
                if len(res[iComp][0].parameterNumbers) > 0:
                    print('      parmeterNumbers for component ' + str(iComp) + ':', end='')
                    print(res[iComp][0].parameterNumbers)
                    print('      parameterValues for component ' + str(iComp) + ':', end='')
                    roundedVals = np.around(res[iComp][0].means, 3)
                    print(roundedVals)
            else: print('      Component ' + str(iComp) + ' not estimable')#ode ins Spiel bringen


######################################################################################################
#private helper for coversion to JSON
    def _storeInJsonResults(_, algo: str, res: list[StepResult], percentNoise: float):
        sr_all = {}
        for i in range(len(res)):
            sr = {}
            if len(res[i]) > 0:
                sr[C.means] = res[i][0].means
                sr[C.stddevs] = res[i][0].stddevs
                sr[C.parameterNumbers] = res[i][0].parameterNumbers
                sr[C.successfulSampleCount] = res[i][0].successfulSampleCount
                
            sr_all[i] = sr
            
        _.jsonResults[algo][round(percentNoise, 7)] = sr_all   
