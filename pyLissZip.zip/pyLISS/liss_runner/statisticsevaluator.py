import numpy
from liss_runner.constants import Constants as C

################################################################################
#_ctor()
class  StatisticsEvaluator:
    def __init__(_,stats: list, algos: list):
        _.statsList = stats
        _.algos = algos
        _.noiseLevels = numpy.array(_._getNoiseLevels())


    def _getNoiseLevels(_):
        myStats = _.statsList[0]
        myAlgoKeys = myStats.keys()
        myAlgoResults = myStats[list(myAlgoKeys)[0]]
        myComponents = myAlgoResults[C.correctModel]
        myComp = myComponents[list(myComponents.keys())[0]]
        
        return myComp[C.noiseLevel]

        
################################################################################
    def evaluateStatistics(_):
        res = {}
        res[C.noiseLevel] = _.noiseLevels
        for algo in _.algos:
            algoStat = {}
            _._addPercentageOfCorrectModel(algo, algoStat)
            _._addPercentageOfSuccessfulSamples(algo, algoStat)
            _._addAverageDeviationOfParameters(algo, algoStat)
            res[algo] = algoStat
        return res


################################################################################
    def _addPercentageOfCorrectModel(_, algo: str, algoStat: dict):
        correct = numpy.zeros(len(_.noiseLevels))
        allAttempts = numpy.zeros(len(_.noiseLevels))
        allOnes = numpy.ones(len(_.noiseLevels))
        for i in range(len(_.statsList)):
            correctModelDict = _.statsList[i][algo][C.correctModel]
            for comp in correctModelDict.keys():
                correct = correct + correctModelDict[comp][C.modelCorrect]
                allAttempts = allAttempts + allOnes
        correctPercent = numpy.divide(correct*100.0, allAttempts)
        algoStat[C.percentageOfCorrectModels] = correctPercent
        algoStat[C.numberOfEstimatedEquations] = allAttempts[0]

        
    def _addPercentageOfSuccessfulSamples(_, algo: str, algoStat: dict):
        correct = 0.0
        numEquations = 0.0
        for i in range(len(_.statsList)):
            sampleSuccessDict = _.statsList[i][algo][C.percentageSuccessfulSamples]
            for comp in sampleSuccessDict.keys():
                correct = correct + sampleSuccessDict[comp]
                numEquations = numEquations + 1.0
        algoStat.update({C.percentageOfSuccessfulSamples: correct/numEquations})
                 
        
    def _addAverageDeviationOfParameters(_, algo: str, algoStat: dict):
        parDev = {}
        parCount = {}
        for i in range(len(_.noiseLevels)):
            parDev.update({_.noiseLevels[i]: 0.0})
            parCount.update({_.noiseLevels[i]: 0.0})
            
        for i in range(len(_.statsList)):
            parStatsDict = _.statsList[i][algo][C.parameterValueStatistics]
            for comp in parStatsDict.keys():
                correctNoiseLevels = parStatsDict[comp][C.noiseLevelWithCorrectModel]
                deviations = parStatsDict[comp][C.meanParameterDeviation]
                for j in range(len(correctNoiseLevels)):
                    parDev[correctNoiseLevels[j]] = parDev[correctNoiseLevels[j]] + deviations[j]
                    parCount[correctNoiseLevels[j]] = parCount[correctNoiseLevels[j]] + 1.0

        for key in parDev:
            if parCount[key] > 0.001: parDev[key] = parDev[key]/parCount[key]
            else: parDev[key] = -1.1111
        algoStat.update({C.percentParameterDeviation: parDev})
