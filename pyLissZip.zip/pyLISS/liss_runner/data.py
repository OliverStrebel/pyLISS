import numpy as np

class Data:
    def __init__(self
                 , odeName: str
                 , t_: np.ndarray
                 , data: np.ndarray
                 , jsonReferenceData: dict
                 , jsonConfig: dict
                 , fileName: str):
        self.odeName = odeName
        self.t = t_
        self.odeData = data
        self.jsonReferenceData = jsonReferenceData
        self.jsonConfiguration = jsonConfig
        self.fileName = fileName

