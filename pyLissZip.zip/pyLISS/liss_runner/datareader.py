import csv
import json
import numpy as np
import os

import liss_runner.data
from liss_runner.data import Data


def readAll(fName):
    raw = _readRawData(fName)
    t = raw[:,0]
    return Data(_getODEName(fName)
                , t
                , _removeColumns(raw)
                , _readRefData(fName)
                , _readConfig(fName)
                , fName) 


######################################################################################################
#private helpers for data
def _readRawData(fileName):
    rawFile = open(fileName)
    raw = np.loadtxt(rawFile, delimiter=' ')#default: float
    rawFile.close()
    return raw


def _removeColumns(raw):
    j = raw[0,:].size
    while j > 0:
        raw = np.delete(raw, j-2, 1)
        j-=2
    return raw


def _getODEName(fileName):
    theFile=os.path.basename(fileName)
    baseName, extension = os.path.splitext(theFile)
    return baseName


######################################################################################################
#private helpers for reference data
def _readRefData(fileName):
    csvFile = _openFile(fileName)
    csvDict = csv.DictReader(csvFile, delimiter=';')
    refData = _createRefDataFromDict(csvDict)
    csvFile.close()
    return refData


def _openFile(fileName):
    baseName, extension = os.path.splitext(fileName)
    refFileName = baseName + '.ref'
    return open(refFileName)


def _createRefDataFromDict(csvDict) -> dict:
    dictPar, dictVal, dictMonome = ({} for i in range(3))

    for row in csvDict:
        if dictPar.get(int(row['ComponentNo'])) is None:
            dictPar.update({int(row['ComponentNo']): [int(row['ParameterNo'])]})
            dictVal.update({int(row['ComponentNo']): [float(row['ParameterValue'])]})
            dictMonome.update({int(row['ComponentNo']): [row['ParameterMonome']]})
        else:
            dictPar.get(int(row['ComponentNo'])).append(int(row['ParameterNo']))
            dictVal.get(int(row['ComponentNo'])).append(float(row['ParameterValue']))
            dictMonome.get(int(row['ComponentNo'])).append(row['ParameterMonome'])

    refData = {}
    for key in dictPar:
        leafComp = {}
        leafComp["parameterNumbers"] = dictPar[key]
        leafComp["parameterValues"] = dictVal[key]
        leafComp["parameterMonomes"] = dictMonome[key]
        refData[key] = leafComp
        
    return refData


######################################################################################################
#private helpers for json configuration data
def _readConfig(fileName):
    baseName, extension = os.path.splitext(fileName)
    configFileName = baseName + '.json'
    configFile = open(configFileName)
    jsn = json.load(configFile)
    configFile.close()
    return jsn
