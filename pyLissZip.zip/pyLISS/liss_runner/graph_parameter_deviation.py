import numpy
import matplotlib.pyplot as plt
from liss_runner.constants import Constants as C


def writeParamDeviationPercent(stats, algos):
    noiseLevels = numpy.array(stats[C.noiseLevel], dtype=numpy.dtype(float))*100.0
    myMarkers=['x', 'o', 'D', 's']
    myFaceColors=['black', 'none', 'none', 'black']
    i = 0
    plt.xlim(-0.1, 2.1)
    plt.xticks([0.0, 0.5, 1.0, 1.5, 2.0])
    plt.xlabel("$q$")
    plt.ylabel("$<d>$")

    for algo in algos:
        if (algo != 'INT_EN'):
            plt.scatter(noiseLevels,
                        stats[algo][C.percentParameterDeviation].values(),
                        marker=myMarkers[i],
                        color='black',
                        facecolors=myFaceColors[i],
                        label=algo)
            plt.plot(noiseLevels,
                     stats[algo][C.percentParameterDeviation].values(),
                     color='black',
                     linestyle='dotted')
            i=i+1

    plt.legend()
    plt.savefig('output_files/MeanDeviationParameters.jpeg')
 
