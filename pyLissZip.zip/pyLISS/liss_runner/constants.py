class Constants:
    DIF_EF = "DIF_EF"
    DIF_EN = "DIF_EN"
    INT_EF = "INT_EF"
    INT_EN = "INT_EN"
    algos = [DIF_EF, DIF_EN, INT_EF, INT_EN] 
    REFERENCE_DATA = "REFERENCE_DATA"
    CONFIGURATION = "CONFIGURATION"

    

    sigmaSteps = "sigmaSteps"
    sigmaStart = "sigmaStart"
    sigmaDelta = "sigmaDelta"
    tangentRegressionSize = "tangentRegressionSize"

    sigmaScale = "sigmaScale"
    sampleSize = "sampleSize"
    sampleCount = "sampleCount"
    tangentRegressionSize = "tangentRegressionSize"

    means = "means"
    stddevs = "stddevs"

    estimationFunction = "estimationFunction"
    Cubic2D = "2DCubic"
    Cubic3D = "3DCubic"
    Cubic4D = "4DCubic"
    Driven3D = "Driven3D"
    
    percentageSuccessfulSamples = "percentageSuccessfulSamples"
    correctModel = "correctModel"
    successfulSampleCount = "successfulSampleCount"
    sampleCount = "sampleCount"
    parameterNumbers = "parameterNumbers"
    parameterValues = "parameterValues"
    noiseLevel = "noiseLevel"
    modelCorrect = "modelCorrect"
    noiseLevelWithCorrectModel = "noiseLevelWithCorrectModel"
    meanParameterDeviation = "meanParameterDeviation"
    parameterValueStatistics = "parameterValueStatistics"
    percentCorrectModels = "percentCorrectModels"
    percentParameterDeviation = "percentParameterDeviation"
    
    percentageOfCorrectModels = "percentageOfCorrectModels"
    percentageOfSuccessfulSamples = "percentageOfSuccessfulSamples"
    numberOfEstimatedEquations = "numberOfEstimatedEquations"
    
