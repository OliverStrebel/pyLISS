import sys
import os
import json

import matplotlib.pyplot as plt

import evaluation_of_experimental_data.experimentaldatareader as exp_dataReader
from evaluation_of_experimental_data.algorithmcaller import AlgorithmCaller
from evaluation_of_experimental_data.ImplicitEulerIntegrator2D3rdDegree import ImplicitEulerIntegrator2D3rdDegree
from evaluation_of_experimental_data.simplebockalgorithm import SimpleBockAlgorithm


dataFileName = "evaluation_of_experimental_data/data/2022_10_18_02_rawdata.csv"
data = exp_dataReader.readAll(dataFileName)
caller = AlgorithmCaller(data)
jsonResult = caller.runEstimation()

baseName, extension = os.path.splitext(dataFileName)
outFileName = baseName + '.experimental_liss_result'
with open(outFileName, 'w') as outfile:
    json.dump(jsonResult, outfile, indent=4)

#InterSteps bringen nichts
integrator = ImplicitEulerIntegrator2D3rdDegree(data.t, data.odeData[0,:], jsonResult, 0, [], [])
x_pre = integrator.run()

simpleBock = SimpleBockAlgorithm(data, jsonResult)
x_Bock = simpleBock.run()

plt.xlabel("$x_1 \hspace{0.3} [mV]$")
plt.ylabel("$x_2 \hspace{0.3} [mV]$")

plt.plot(data.odeData[:,0], data.odeData[:,1], color='black', label='Experimental Data')
plt.plot(x_pre[:,0], x_pre[:,1], color='green', label='Preprocessing')
plt.plot(x_Bock[:,0], x_Bock[:,1], color='red', label='Bock')
plt.legend()
plt.savefig('output_files/ExperimentalDataAndModelResults.jpeg')

plt.show()
print('End program')

