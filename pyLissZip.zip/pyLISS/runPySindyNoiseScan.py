import sys
import os
import json

import liss_runner.datareader as dataReader

from pySindy.pysindynoisescan import PySindyNoiseScan


dataFileName = sys.argv[1]
#Example of dataFileName for cmd-Line and 'Run Costomized'-mode of IDLE-Shell:
#dataFileName = "data/Jerks/Jerk_1.dat"
data = dataReader.readAll(dataFileName)
scanner = PySindyNoiseScan(data)
estimates = scanner.runEstimations()

directory, fileName = os.path.split(dataFileName)
bareFileName, extension = os.path.splitext(fileName)
outFileName = 'pySindy/data/' + bareFileName + '.pysindy_result'
with open(outFileName, 'w') as outfile:
    json.dump(estimates, outfile, indent=4)

print('End program')

