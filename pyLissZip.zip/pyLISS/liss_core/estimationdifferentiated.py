import numpy
import math
import scipy

from scipy.linalg import solve

from liss_core.estimationbase import EstimationBase
from liss_core.parameters import Parameters

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class  EstimationDifferentiated(EstimationBase):
    def __init__(_
                 , ode: list[PolynomEstimationFunction]
                 , par: Parameters
                 , X: numpy.ndarray
                 , t: numpy.ndarray
                 , bEffect: bool):
        super().__init__(ode, par, X, t, bEffect)
        _.sampleCoordinates = list(numpy.empty([len(ode)]) for i in range(par.sampleSize))
        _.sampleTangents = list(numpy.empty([len(ode)]) for i in range(par.sampleSize))

                
######################################################################################################
#Overridden methods of EstimationBase
    def _setEquationSystem(_, iComp: int, A: numpy.ndarray, b: numpy.ndarray):
        for i in range(len(_.sampleIndices)):
            b[i] = _.sampleTangents[i][iComp]
            _.ode[iComp].setMatrix(i, A, _.sampleCoordinates[i])
        

    def _prepareSample(_):
        for k in range(len(_.sampleIndices)):
            for iComp in range(len(_.ode)):
                _._setDataLinearRegression(k, iComp)


######################################################################################################
#private helpers for _prepareSample
    def _setDataLinearRegression(_, k: int, iComp: int):
        iSize = _.par.tangentRegressionSize
        iPos = _.sampleIndices[k]
        A = numpy.empty([2*iSize + 1, 2])
        b = numpy.empty([2*iSize + 1])
        
        for i in range(-iSize, iSize):
            b[iSize+i] = _.X[iPos+i, iComp]
            A[iSize+i, 0] = 1.0
            A[iSize+i, 1] = _.t[iPos+i] - _.t[iPos]

        AT = numpy.matrix.transpose(A)
        x = numpy.linalg.solve(numpy.matmul(AT, A), numpy.matmul(AT, b))
        if (math.isnan(x[0]) or math.isnan(x[1])):
            raise FloatingPointError( '_setDataLinearRegression: result not a number')

        _.sampleCoordinates[k][iComp] = x[0]
        _.sampleTangents[k][iComp] = x[1]


