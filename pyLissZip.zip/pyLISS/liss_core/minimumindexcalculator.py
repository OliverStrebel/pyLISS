import numpy as np
import scipy
import math
import sys


class MinimumIndexCalculator:
    def __init__(_, sigmaScale: float):
        _.sigmaScale = sigmaScale
        
        
    def getMinIndexEf(_
                      , means: np.ndarray
                      , sd: np.ndarray) -> int:
        iMin = -1
        if len(means) <= 1: return iMin
        dMin = sys.float_info.max
        for i in range(len(means)):
            if (abs(means[i]) < _.sigmaScale*sd[i]) and (abs(means[i])/sd[i] < dMin):
                iMin = i
                dMin = abs(means[i])/sd[i]
        
        return iMin


    def getMinIndexEn(_
                      , samples: list
                      , means: np.ndarray) -> int:
        if len(means) <= 1: return -1
        S = _._getMatrix(samples, means)
        SR = S.copy()
        return _._getMin(SR, _._calculateSubDeterminants(S)) 


################################################################################
# mean and stddev utility functions
    def getMeans(_, samples: list) -> np.ndarray:
        means = np.zeros([len(samples[0])])
        for i in range(len(samples)):
            for j in range(len(samples[0])):
                means[j] = means[j] + samples[i][j]
                
        for j in range(len(means)):
            means[j] = means[j]/(1.0*len(samples))                
        return means


    def getStdDevs(_, samples: list, means: np.ndarray) -> np.ndarray:
        stddevs = np.zeros([len(means)])
        for j in range(len(stddevs)):
            d = 0.0
            for i in range(len(samples)):
                d = d + math.pow(means[j] - samples[i][j], 2.0)
            stddevs[j] = math.sqrt(d/(1.0*len(samples)))
        return stddevs


################################################################################
# getMinIndexEn-helpers
    def _getMatrix(_, s: list, m: np.ndarray) -> np.ndarray:
        S = np.zeros((len(m), len(m)))
        for k in range(len(s)):
            for i in range(len(S[:,0])):
                for j in range(len(S[0,:])):
                    S[i,j] = S[i,j] + (s[k][i] - m[i])*(s[k][j] - m[j])/(m[i]*m[j])
        return S*(_.sigmaScale*_.sigmaScale/len(s))
        

    def _getMin(_, SR: np.ndarray, dets: np.ndarray) -> int:
        k = len(SR[0,:])
        detSR = scipy.linalg.det(SR)
        dMin = _._getEntropy(k, detSR)

        iMin = -1
        for i in range(len(dets)):
            if dets[i] < dMin:
                dMin = dets[i]
                iMin = i
        return iMin
        

    def _calculateSubDeterminants(_, S: np.ndarray) -> np.ndarray:
        k = len(S[0,:]) - 1 
        dets = np.zeros([len(S[0,:])])
        for i in range(len(dets)):
            S_ = _._getSubMatrix(S, i)
            det = scipy.linalg.det(S_)
            dets[i] = _._getEntropy(k, det)
        return dets


    def _getSubMatrix(_, S: np.ndarray, iPos: int) -> np.ndarray:
        dim = len(S[0,:])-1
        S_ = np.zeros((dim, dim))
        i_ = 0
        for i in range(len(S[:,0])):
            if i != iPos:
                j_ = 0
                for j in range(len(S[0,:])):
                    if j != iPos:
                        S_[i_, j_] = S[i,j]
                        j_ = j_ + 1
                i_ = i_ + 1
        return S_


    def _getEntropy(_, k: int, det: float) -> float:
        return 0.5*k + 0.5*k*math.log(2.0*math.pi) + 0.5*math.log(det)

