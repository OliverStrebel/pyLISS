import numpy as np

from liss_core.parameters import Parameters
from liss_core.estimationdifferentiated import EstimationDifferentiated
from liss_core.estimationintegrated import EstimationIntegrated

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction
    


class Facade:
    def __init__(_
                 , ode: list[PolynomEstimationFunction]
                 , parameters: Parameters):
        _.ode = ode
        _.par = parameters
        
        
    def estimateDifEf(_, X: np.ndarray, t: np.ndarray):
        _._checkInput(X, t)
        calculator = EstimationDifferentiated(_._cloneODE(), _.par, X, t, True)
        return calculator.getModel()


    def estimateDifEn(_, X: np.ndarray, t: np.ndarray):
        _._checkInput(X, t)
        calculator = EstimationDifferentiated(_._cloneODE(), _.par, X, t, False)
        return calculator.getModel()


    def estimateIntEf(_, X: np.ndarray, t: np.ndarray):
        _._checkInput(X, t)
        calculator = EstimationIntegrated(_._cloneODE(), _.par, X, t, True)
        return calculator.getModel()


    def estimateIntEn(_, X: np.ndarray, t: np.ndarray):
        _._checkInput(X, t)
        calculator = EstimationIntegrated(_._cloneODE(), _.par, X, t, False)
        return calculator.getModel()


######################################################################################################
#private helpers for input chekc
    def _cloneODE(_):
        ode = []
        for i in range(len(_.ode)):
            ode.append(_.ode[i].clone())
        return ode


######################################################################################################
#private helpers for input chekc
    def _checkInput(_, X: np.ndarray, t: np.ndarray):
        _._checkTypes(X, t)
        _._checkShapes(X, t)
        _._checkParameters(X)
        _._checkNestedTypes(X, t)
        _._checkODE()
        

    def _checkTypes(_, X: np.ndarray, t: np.ndarray):
        if not isinstance(X, np.ndarray):
            raise Exception('lisscore.Facade: X ist not of type np.ndarray')
        if not isinstance(t, np.ndarray):
            raise Exception('lisscore.Facade: t ist not of type np.ndarray')
        
        if not isinstance(_.ode, list):
            raise Exception('lisscore.Facade: _.ode ist not of type list')
        for i in range(len(_.ode)):
            if not isinstance(_.ode[i], PolynomEstimationFunction):
                raise Exception('lisscore.Facade: _.ode[i] ist not of type PolynomEstimationFunction')

        if not isinstance(_.par, Parameters):
            raise Exception('lisscore.Facade: _.par ist not of type Parameters')
        if not isinstance(_.par.sigmaScale, float):
            raise Exception('lisscore.Facade: _.par.sigmaScale ist not of type float')
        if not isinstance(_.par.sampleSize, int):
            raise Exception('lisscore.Facade: _.par.sampleSize, ist not of type int')
        if not isinstance(_.par.sampleCount, int):
            raise Exception('lisscore.Facade: _.par.sampleCount ist not of type int')
        if not isinstance(_.par.tangentRegressionSize, int):
            raise Exception('lisscore.Facade: _.par.tangentRegressionSize ist not of type int')


    def _checkShapes(_, X: np.ndarray, t: np.ndarray):
        if t.ndim != 1:
            raise Exception('lisscore.Facade: t must be 1-dimensional')
        if X.ndim != 2:
            raise Exception('lisscore.Facade: X must be 2-dimensional')

        jTest = len(X[0,:])
        if jTest < 2: #One dimensional ode are easy to estimate
            raise Exception('lisscore.Facade: ODE-System must have at least 2 components')
        if jTest != len(_.ode):
            raise Exception('lisscore.Facade: X does not match ODE-System')
        for i in range(len(X[:,0])):
            if jTest != len(X[i,:]):
                raise Exception('lisscore.Facade: X must be rectangular')        
            
        iTest = len(X[:,0])
        for j in range(len(X[0,:])):
            if iTest != len(X[:,j]):
                raise Exception('lisscore.Facade: X must be rectangular')        
        if iTest != len(t):
            raise Exception('lisscore.Facade: X and t must have the same number of rows')        
           
        
    def _checkParameters(_, X: np.ndarray):
        if _.par.sampleCount < 20:
            raise Exception('lisscore.Facade: Parameters.sampleCount must be at least 20')        
        if _.par.sampleSize < 100:
            raise Exception('lisscore.Facade: Parameters.sampleSize must be 5 to 10 times the numbers of parameters ')        
        if _.par.tangentRegressionSize < 5:
            raise Exception('lisscore.Facade: Parameters.tangentRegressionSize must be at least 5')        
        if _.par.sigmaScale < 2.0 or _.par.sigmaScale > 4.0:
            raise Exception('lisscore.Facade: Parameters.sigmaScale must be between 2.0 an 4.0')        

        iTest = len(X[:,0])
        if iTest - 4*_.par.tangentRegressionSize < 10*_.par.sampleSize:
            raise Exception('lisscore.Facade: Not enough data rows in X')        
            

    def _checkNestedTypes(_, X: np.ndarray, t: np.ndarray):
        if not isinstance(X[0,0], float):
            raise Exception('lisscore.Facade: X must contain float values') 
        if not isinstance(t[0], float):
            raise Exception('lisscore.Facade: t must contain float values')


    def _checkODE(_):
        for i in range(len(_.ode)):
            if _.ode[i].isEstimable():
                if _.ode[i].getAvailableParameterCount() != _.ode[i].getActiveParameterCount():
                    raise Exception('PolynomEstimationFunction already contains inactive parameters')


