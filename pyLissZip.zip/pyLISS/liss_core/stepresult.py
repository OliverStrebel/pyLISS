class StepResult:
    def __init__(self):
        self.means = list()
        self.stddevs = list()
        self.parameterNumbers = list()
        self.successfulSampleCount = 0
