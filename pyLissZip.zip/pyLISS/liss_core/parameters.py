class Parameters:
    def __init__(self
	         , sigmaScale: float
	         , sampleSize: int
	         , sampleCount: int
	         , tangentRegressionSize: int):
        self.sigmaScale = sigmaScale
        self.sampleSize = sampleSize
        self.sampleCount = sampleCount
        self.tangentRegressionSize = tangentRegressionSize
