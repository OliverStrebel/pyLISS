import numpy
import random
import math

from liss_core.estimationbase import EstimationBase
from liss_core.parameters import Parameters

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class  EstimationIntegrated(EstimationBase):
    def __init__(_
                 , ode: list[PolynomEstimationFunction]
                 , par: Parameters
                 , X: numpy.ndarray
                 , t: numpy.ndarray
                 , bEffect: bool):
        super().__init__(ode, par, X, t, bEffect)
        _.bi = numpy.zeros((len(X[:,0]), len(ode)))
        _.Ai = numpy.zeros(((len(X[:,0]), _._getSize(ode))))
        _._setIntegratedData()
                                      
            
######################################################################################################
#Overridden methods of EstimationBase
    def _setEquationSystem(_, iComp: int, A: numpy.ndarray, b: numpy.ndarray):
        for i in range(len(_.sampleIndices)):
            b[i] = _.bi[_.sampleIndices[i], iComp]
            k = 0
            for j in range(_.ode[iComp].getAvailableParameterCount()):
                if _.ode[iComp].isActive(j):
                    A[i,k] = _.Ai[_.sampleIndices[i], j]
                    k = k+1
        

    def _prepareSample(_):
        msg = 'doNothing'
        

######################################################################################################
#private helpers for constructor
    # The first row in the integrated feature matrix Ai is zero.
    # The first entry of bi is also zero.
    # This doesnt matter since:
    #     1. The row simply drops out in forming Ai^T * Ai and Ai^T * b
    #     2. During subsampling this row is not used for regression
    def _setIntegratedData(_):
        Tmp = numpy.zeros((len(_.X[:,0]), len(_.Ai[0,:])))
        for i in range(len(_.bi[:,0])):
            _.ode[_._index()].setMatrix(i, Tmp, _.X[i,:])
            for j in range(len(_.bi[0,:])):
                _.bi[i,j] = _.X[i,j] - _.X[0,j]

        #integrateMatrix with trapezoid rule
        for j in range(len(_.Ai[0,:])):
            for i in range(1, len(_.Ai[:,0])):
                _.Ai[i,j] = _.Ai[i-1,j] + 0.5*(_.t[i] - _.t[i-1])*(Tmp[i,j] + Tmp[i-1,j])
                       
        
    def _getSize(_, ode: list[PolynomEstimationFunction]) -> int:
        for iComp in range(len(ode)):
            if ode[iComp].isEstimable():
                return ode[iComp].getAvailableParameterCount()


    def _index(_) -> int:
        for iComp in range(len(_.ode)):
            if _.ode[iComp].isEstimable(): return iComp

