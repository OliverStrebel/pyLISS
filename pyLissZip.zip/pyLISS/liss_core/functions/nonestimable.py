import numpy as np

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class Nonestimable(PolynomEstimationFunction):
    def __init__(self):
        super().__init__(0)


    def clone(self) -> PolynomEstimationFunction: return Nonestimable()


    def isEstimable(self) -> bool:
        return False
