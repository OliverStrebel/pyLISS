import numpy as np

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class Cubic3D(PolynomEstimationFunction):
    def __init__(self):
        super().__init__(20)


    def clone(self) -> PolynomEstimationFunction: return Cubic3D()


    ## Polynom:
    ##      p0 + p1*x + p2*y + p3*z
    ##    + p4*x^2 + p5*xy + p6*xz + p7*y^2 + p8*yz + p9*z^2
    ##    + p10*x^3 + p11*x^2y + p12*x^2z + p13*xy^2
    ##    + p14*xyz + p15*xz^2 + p16*y^3 + p17*y^2z + p18*yz^2 + p19*z^3
    ##
    ##    s: state vector
    def setMatrix(self, iPos: int, A: np.ndarray, s: np.ndarray):
        iPar = 0
        if self.isActive(0):
            A[iPos, iPar] = 1.0
            iPar += 1
        if self.isActive(1):
            A[iPos, iPar] = s[0]
            iPar += 1
        if self.isActive(2):
            A[iPos, iPar] = s[1]
            iPar += 1
        if self.isActive(3):
            A[iPos, iPar] = s[2]
            iPar += 1

        if self.isActive(4):
            A[iPos, iPar] = pow(s[0], 2.0)
            iPar += 1
        if self.isActive(5):
            A[iPos, iPar] = s[0]*s[1]
            iPar += 1
        if self.isActive(6):
            A[iPos, iPar] = s[0]*s[2]
            iPar += 1
        if self.isActive(7):
            A[iPos, iPar] = pow(s[1], 2.0)
            iPar += 1
        if self.isActive(8):
            A[iPos, iPar] = s[1]*s[2]
            iPar += 1
        if self.isActive(9):
            A[iPos, iPar] = pow(s[2], 2.0 )
            iPar += 1

        if self.isActive(10):
            A[iPos, iPar] = pow(s[0], 3.0)
            iPar += 1
        if self.isActive(11):
            A[iPos, iPar] = pow(s[0], 2.0)*s[1]
            iPar += 1
        if self.isActive(12):
            A[iPos, iPar] = pow(s[0], 2.0)*s[2]
            iPar += 1
        if self.isActive(13):
            A[iPos, iPar] = pow(s[1], 2.0)*s[0]
            iPar += 1
        if self.isActive(14):
            A[iPos, iPar] = s[0]*s[1]*s[2]
            iPar += 1
        if self.isActive(15):
            A[iPos, iPar] = pow(s[2], 2.0)*s[0]
            iPar += 1
        if self.isActive(16):
            A[iPos, iPar] = pow(s[1], 3.0 )
            iPar += 1
        if self.isActive(17):
            A[iPos, iPar] = pow(s[1], 2.0)*s[2]
            iPar += 1
        if self.isActive(18):
            A[iPos, iPar] = pow(s[2], 2.0)*s[1]
            iPar += 1
        if self.isActive(19):
            A[iPos, iPar] = pow(s[2], 3.0 )


    def isEstimable(self) -> bool:
        return True
