import numpy as np

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class Cubic4D(PolynomEstimationFunction):
    def __init__(self):
        super().__init__(35)


    def clone(self) -> PolynomEstimationFunction: return Cubic4D()


    def setMatrix(self, iPos: int, A: np.ndarray, s: np.ndarray):
        iPar = 0
        
        # p_0 + p_1*x_1 + p_2*x_2 + p_3*x_3 + p_4*x_4
        if self.isActive(0):
            A[iPos, iPar] = 1.0
            iPar += 1
        if self.isActive(1):
            A[iPos, iPar] = s[0]
            iPar += 1
        if self.isActive(2):
            A[iPos, iPar] = s[1]
            iPar += 1
        if self.isActive(3):
            A[iPos, iPar] = s[2]
            iPar += 1
        if self.isActive(4):
            A[iPos, iPar] = s[3]
            iPar += 1

        # p_5*x_1^2 + p_6*x_1*x_2 + p_7*x_1*x_3 + p_8*x_1*x_4
        if self.isActive(5):
            A[iPos, iPar] = pow(s[0], 2.0)
            iPar += 1
        if self.isActive(6):
            A[iPos, iPar] = s[0]*s[1]
            iPar += 1
        if self.isActive(7):
            A[iPos, iPar] = s[0]*s[2]
            iPar += 1
        if self.isActive(8):
            A[iPos, iPar] = s[0]*s[3]
            iPar += 1
            
        # p_9*x_2^2 + p_10*x_2*x_3 + p_11*x_2*x_4
        # + p_12*x_3^2 + p_13*x_3*x_4 + p_14*x_4^2
        if self.isActive(9):
            A[iPos, iPar] = pow(s[1], 2.0)
            iPar += 1
        if self.isActive(10):
            A[iPos, iPar] = s[1]*s[2]
            iPar += 1
        if self.isActive(11):
            A[iPos, iPar] = s[1]*s[3]
            iPar += 1
        if self.isActive(12):
            A[iPos, iPar] = pow(s[2], 2.0)
            iPar += 1
        if self.isActive(13):
            A[iPos, iPar] = s[2]*s[3]
            iPar += 1
        if self.isActive(14):
            A[iPos, iPar] = pow(s[3], 2.0)
            iPar += 1

        # p_15*x_1^3 + p_16*x_1^2*x_2 + p_17*x_1^2*x_3 + p_18*x_1^2*x_4
        if self.isActive(15):
            A[iPos, iPar] = pow(s[0], 3.0)
            iPar += 1
        if self.isActive(16):
            A[iPos, iPar] = pow(s[0], 2.0)*s[1]
            iPar += 1
        if self.isActive(17):
            A[iPos, iPar] = pow(s[0], 2.0)*s[2]
            iPar += 1
        if self.isActive(18):
            A[iPos, iPar] = pow(s[0], 2.0)*s[3]
            iPar += 1
        
        # p_19*x_1*x_2^2 + p_20*x_1*x_2*x_3 + p21*x_1*x_2*x_4
        # + p_22*x_1*x_3^2 + p_23*x_1*x_3*x_4 + p_24*x_1*x_4^2     
        if self.isActive(19):
            A[iPos, iPar] = s[0]*pow(s[1], 2.0)
            iPar += 1
        if self.isActive(20):
            A[iPos, iPar] = s[0]*s[1]*s[2]
            iPar += 1
        if self.isActive(21):
            A[iPos, iPar] = s[0]*s[1]*s[3]
            iPar += 1
        if self.isActive(22):
            A[iPos, iPar] = s[0]*pow(s[2], 2.0)
            iPar += 1
        if self.isActive(23):
            A[iPos, iPar] = s[0]*s[2]*s[3]
            iPar += 1
        if self.isActive(24):
            A[iPos, iPar] = s[0]*pow(s[3], 2.0)
            iPar += 1

        # p_25*x_2^3 + p_26*x_2^2*x_3 + p_27*x_2^2*x_4
        # + p_28*x_2*x_3^2 + p_29*x_2*x_3*x_4 + p_30*x_2*x_4^2
        if self.isActive(25):
            A[iPos, iPar] = pow(s[1], 3.0)
            iPar += 1
        if self.isActive(26):
            A[iPos, iPar] = pow(s[1], 2.0)*s[2]
            iPar += 1
        if self.isActive(27):
            A[iPos, iPar] = pow(s[1], 2.0)*s[3]
            iPar += 1
        if self.isActive(28):
            A[iPos, iPar] = s[1]*pow(s[2], 2.0)
            iPar += 1
        if self.isActive(29):
            A[iPos, iPar] = s[1]*s[2]*s[3]
            iPar += 1
        if self.isActive(30):
            A[iPos, iPar] = s[1]*pow(s[3], 2.0)
            iPar += 1

        # p_31*x_3^3 + p_32*x_3^2*x_4 + p_33*x_3*x_4^2 + p_34*x_4^3
        if self.isActive(31):
            A[iPos, iPar] = pow(s[2], 3.0)
            iPar += 1
        if self.isActive(32):
            A[iPos, iPar] = pow(s[2], 2.0)*s[3]
            iPar += 1
        if self.isActive(33):
            A[iPos, iPar] = s[2]*pow(s[3], 2.0)
            iPar += 1
        if self.isActive(34):
            A[iPos, iPar] = pow(s[3], 3.0)
            iPar += 1


    def isEstimable(self) -> bool:
        return True
