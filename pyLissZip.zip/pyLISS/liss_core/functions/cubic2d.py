import numpy as np

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class Cubic2D(PolynomEstimationFunction):
    def __init__(self):
        super().__init__(10)


    def clone(self) -> PolynomEstimationFunction: return Cubic2D()


    ## Polynom:
    ##      p0 + p1*x + p2*y
    ##    + p3*x^2 + p4*xy + p5*y^2
    ##    + p6*x^3 + p7*x^2y + p8*xy^2 + p9*y^3
    ##
    ##    s: state vector
    def setMatrix(self, iPos: int, A: np.ndarray, s: np.ndarray):
        iPar = 0
        if self.isActive(0):
            A[iPos, iPar] = 1.0
            iPar += 1
        if self.isActive(1):
            A[iPos, iPar] = s[0]
            iPar += 1
        if self.isActive(2):
            A[iPos, iPar] = s[1]
            iPar += 1

        if self.isActive(3):
            A[iPos, iPar] = pow(s[0], 2.0)
            iPar += 1
        if self.isActive(4):
            A[iPos, iPar] = s[0]*s[1]
            iPar += 1
        if self.isActive(5):
            A[iPos, iPar] = pow(s[1], 2.0)
            iPar += 1

        if self.isActive(6):
            A[iPos, iPar] = pow(s[0], 3.0)
            iPar += 1
        if self.isActive(7):
            A[iPos, iPar] = pow(s[0], 2.0)*s[1]
            iPar += 1
        if self.isActive(8):
            A[iPos, iPar] = pow(s[1], 2.0)*s[0]
            iPar += 1
        if self.isActive(9):
            A[iPos, iPar] = pow(s[1], 3.0 )
            iPar += 1


    def isEstimable(self) -> bool:
        return True
