import numpy as np


class PolynomEstimationFunction:
    def __init__(self,
	         monomeCount: int):
        self.parameterIsActive = [True for i in range(monomeCount)]


    def setMatrix(self, i: int, A: np.ndarray, state: np.ndarray):
        raise NotImplementedError(
              'PolynomEstimationFunction.setMatrix mut be overridden!')


    def clone(self):
        raise NotImplementedError(
              'PolynomEstimationFunction.clone mut be overridden!')


    # only overridden methods represent Estimable Functions
    def isEstimable(self) -> bool:
        return False

    
    def getAvailableParameterCount(self) -> int:
        return len(self.parameterIsActive)

    
    def getActiveParameterCount(self) -> int:
        i = 0
        for k in range(len(self.parameterIsActive)):
            if self.parameterIsActive[k]:
                i += 1
        return i

    
    def isActive(self, i: int) -> bool:
        return self.parameterIsActive[i]

    
    def setActivity(self, i: int, b: bool):
        self.parameterIsActive[i] = b

