import math
import numpy as np

from scipy.linalg import lstsq
from scipy.linalg import qr
from scipy.linalg import solve_triangular

# Scaled and centered least square INSPIRED BY
#
# G. Seber and A. Lee
# Linear Regression Analysis Second edition 2003
# John Wiley and Sons: Hoboken, New Jersey, USA
# p. 69 ff
#
#Note that this procedure is different from Seber and Lee.
#It scales the rows so that the first column of AT_A contains ones
#The other columns contain numbers out of the interval [-3.0, 3.0]
#with a probability of roughly 99% due to standardization.
def solveNormal(A: np.ndarray, b: np.ndarray) -> np.ndarray:
    means = np.zeros([len(A[0,:])])
    sigmas = np.zeros([len(A[0,:])])

    AT = np.matrix.transpose(A)
    AT_A = np.matmul(AT, A)
    AT_b = np.matmul(AT, b)

    _scaleRows(AT_A, AT_b)
    _standardize(AT_A, means, sigmas)    
    x_, res, r, s = lstsq(AT_A, AT_b, lapack_driver='gelsy')
        
    return _unstandardize(x_, means, sigmas)


def _scaleRows(A: np.ndarray, b: np.ndarray):
    for i in range(len(A[:,0])):
        dScale = A[i,0]
        b[i] = b[i]/dScale
        for j in range(len(A[0,:])):
            A[i,j] = A[i,j]/dScale


def _standardize(A: np.ndarray, means: np.ndarray, sigmas: np.ndarray):
    N = len(A[:,0])
    M = len(A[0,:])
    sigmas[0] = 1.0
    
    for j in range(1, M):
        for i in range(0, N):
            means[j] = means[j] + A[i,j]
    for j in range(1, M): means[j] = means[j]/(1.0*N)    

    for j in range(1, M):
        for i in range(0, N):
            sigmas[j] = sigmas[j] + math.pow(A[i,j] - means[j], 2.0)
    for j in range(1, M): sigmas[j] = math.sqrt(sigmas[j]/(1.0*N))
           
    for i in range(0, N):
        for j in range(1, M): A[i,j] = (A[i,j] - means[j])/sigmas[j]


def _unstandardize(x: np.ndarray, means: np.ndarray, sigmas: np.ndarray):
    M = len(x)
    for j in range(0, M): x[j] = x[j]/sigmas[j]
    for j in range(1, M): x[0] = x[0] - means[j]*x[j]
    return x

