import numpy as np
import random
import math

from scipy.linalg import lstsq

from liss_core.parameters import Parameters
from liss_core.minimumindexcalculator import MinimumIndexCalculator
from liss_core.stepresult import StepResult

from liss_core.functions.polynomestimationfunction import PolynomEstimationFunction


class  EstimationBase:
    def __init__(_
                 , ode: list[PolynomEstimationFunction]
                 , par: Parameters
                 , X: np.ndarray
                 , t: np.ndarray
                 , bEffect: bool):
        _.sampleIndices = [0 for i in range(par.sampleSize)]
        _.evaluatablePoints = list(range(2*par.tangentRegressionSize, len(X[:,0]) - 2*par.tangentRegressionSize))
        _.ode = ode
        _.par = par
        _.X = X
        _.t = t
        _.regressionResults = [list() for i in range(len(ode))]
        _.stepResults = [list() for i in range(len(ode))]
        _.MIC = MinimumIndexCalculator(par.sigmaScale)
        _.isEffect = bEffect
        random.seed(1)

 
############################################################################################
# Main method
# In the following the substeps of step 2 of the algorithms
# are marked by comments
    def getModel(_):
        res, hasSuperfluousParameters = _._init()
        for iComp in range(len(_.ode)):
            if (hasSuperfluousParameters[iComp]): print('      stepping down component ' +str(iComp) + ': ', end='', flush=True)
            while hasSuperfluousParameters[iComp]: #Start step 2
                _._calculateSamples(iComp) #Step 2 (a)
                hasSuperfluousParameters[iComp] = _._evaluateSamples(iComp) #Step 2 (b) and (c)
                if hasSuperfluousParameters[iComp]: print('x', end='', flush=True)
            _._extractData(iComp, res)
            print('')
        return res


######################################################################################################
#template methods
    def _prepareSample(_): #used in _._calculateSamples
        raise NotImplementedError(
              'EstimationBase._prepareSample must be overridden!')


    #used in method _._regression
    def _setEquationSystem(_, iComp: int, A: np.ndarray, b: np.ndarray):
        raise NotImplementedError(
              'EstimationBase._setEquationSystem must be overridden!')


######################################################################################################
#private helpers for getModel
    def _init(_):
        res = [list() for i in range(len(_.ode))]
        hasSuperfluousParameters = []
        for i in range(len(_.ode)):
            hasSuperfluousParameters.append(_.ode[i].isEstimable())
        return res, hasSuperfluousParameters


    def _calculateSamples(_, iComp: int):
        _.regressionResults[iComp].clear()
        for i in range(_.par.sampleCount):
            _.sampleIndices = random.sample(_.evaluatablePoints, _.par.sampleSize) #Step 2 (a) i.
            try:
                _._prepareSample() #Step 2 (a) i.
                _._regression(iComp) #Step 2 (a) ii. and iii.
            except Exception as inst:
                print(type(inst))
                print(inst.args)
                #skip failed subsamples


    #Step 2 (b) and (c)
    def _evaluateSamples(_, iComp: int) -> bool:
        bHasSuperfluousParameters = False
        if len(_.regressionResults[iComp]) < 1:
            _._storeError( iComp, -8)
            return False

        bHasSuperfluousParameters = _._doEvaluateSamples(iComp)
        i = _.ode[iComp].getActiveParameterCount() - _.ode[iComp].getAvailableParameterCount()
        if i == 0:
            _._storeError( iComp, -7)
            return False
        
        return bHasSuperfluousParameters


    def _extractData(_, iComp: int, res: list):
        if (len(_.stepResults[iComp]) > 0):
            res[iComp].append(_.stepResults[iComp][len(_.stepResults[iComp])-1])


######################################################################################################
#private helper for _calculateSamples
    def _regression(_, iComp: int):
        A = np.empty([len(_.sampleIndices), _.ode[iComp].getActiveParameterCount()])
        b = np.empty([len(_.sampleIndices)])
        _._setEquationSystem(iComp, A, b) #Step 2 (a) ii.

        #Step 2 (a) iii.
        x, res, r, s = lstsq(A, b, lapack_driver='gelsy')
        for i in range(len(x)):
            if math.isnan(x[i]):
                raise FloatingPointError( '_regression: result not a number')
        _.regressionResults[iComp].append(x)
        

######################################################################################################
#private helpers for _evaluateSamples 
    def _doEvaluateSamples(_, iComp: int) -> bool:
        bHasSuperfluousParameters = False
        means = _.MIC.getMeans(_.regressionResults[iComp])
        stddevs = _.MIC.getStdDevs(_.regressionResults[iComp], means)
        iMin = -1
        if _.isEffect: iMin = _.MIC.getMinIndexEf(means, stddevs)
        else: iMin = _.MIC.getMinIndexEn(_.regressionResults[iComp], means)
        
        if iMin > -1:
            _._storeResults(iMin, iComp, means, stddevs)
            bHasSuperfluousParameters = True
            
        return bHasSuperfluousParameters
   
        
    def _storeResults(_
                      , iMin: int
                      , iComp: int
                      , means: np.ndarray
                      , stddevs: np.ndarray):
        r = StepResult()
        r.successfulSampleCount = len(_.regressionResults[iComp])
        k = 0
        for j in range(_.ode[iComp].getAvailableParameterCount()):
            if _.ode[iComp].isActive(j):
                if k != iMin:
                    r.parameterNumbers.append(j)
                    r.means.append(means[k])
                    r.stddevs.append(stddevs[k])
                else: _.ode[iComp].setActivity(j, False)
                k = k+1
        if k == 0: _._storeError(iComp, -9)
        else: _.stepResults[iComp].append(r)


    # -9: No active parameter
    # -8: No sample results were found
    # -7: No monome was eliminated
    def _storeError(_, iComp: int, errCode: int):
        r = StepResult()
        r.means.append(errCode)
        r.stddevs.append(errCode)
        r.parameterNumbers.append(errCode)
        r.successfulSampleCount = len(_.regressionResults[iComp])
        _.stepResults[iComp].append(r)
        
        
        


