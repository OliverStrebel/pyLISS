import sys
import os
import json
import glob


from pySindy.pysindyconstants import PySindyConstants as SC
from pySindy.pysindystatisticscollector import StatisticsCollector
from pySindy.pysindystatisticsevaluator import StatisticsEvaluator

import liss_runner.graph_success_percentage as gsp
import liss_runner.graph_parameter_deviation as gpd


curDir = "pySindy/data/"
outDir = "pySindy/output_files"
statsData = []

resultFileSelection = curDir + "*.pysindy_result"
for resultFileName in sorted(glob.glob(resultFileSelection)):
    statsCollector = StatisticsCollector(json.load(open(resultFileName, 'r')))
    baseName, extension = os.path.splitext(resultFileName)
    statsFileName = baseName + '.pysindy_stats'
    print(statsFileName)
    with open(statsFileName, 'w') as outfile:
        json.dump(statsCollector.getStatistics(), outfile, indent=4)


#Read all liss_stats-files
statsFileSelection = curDir + "*.pysindy_stats"
for statsFileName in sorted(glob.glob(statsFileSelection)):
    statsFile = open(statsFileName, 'r')
    statsData.append(json.load(statsFile))

print(len(statsData))


#Evaluate all liss_stats-files and write graphics
statsEvaluator = StatisticsEvaluator(statsData, SC.algos)
stats = statsEvaluator.evaluateStatistics()
gsp.writeSuccessPercent(stats, SC.algos, outDir)
gpd.writeParamDeviationPercent(stats, SC.algos, outDir)


print('End program')

