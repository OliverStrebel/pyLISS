import json

import numpy as np
import numpy.random as npr

import pysindy
from pysindy.differentiation import FiniteDifference
from pysindy.differentiation import SpectralDerivative
from pysindy.differentiation import SmoothedFiniteDifference

from liss_runner.data import Data
from liss_runner.constants import Constants as C

from pySindy.pysindyconstants import PySindyConstants as SC

class PySindyNoiseScan:
    def __init__(_, d: Data):
        _.d = d
        _.cfg = _.d.jsonConfiguration
        _.sigmaSteps = _.cfg[C.sigmaSteps]
        _.sigmaStart = _.cfg[C.sigmaStart]
        _.sigmaDelta = _.cfg[C.sigmaDelta]
        _.jsonResults = {C.REFERENCE_DATA: d.jsonReferenceData
                         , C.CONFIGURATION: d.jsonConfiguration}
        for i in range(0,len(SC.algos)):
            _.jsonResults[SC.algos[i]] = {}


    def runEstimations(_):
        print('ODE: ' + _.d.odeName)
        for i in range(_.sigmaSteps):
            percentNoise = _.sigmaStart + _.sigmaDelta*i
            print( '  percent noise peak to peak: ' +str(round(percentNoise*100, 2)))
            noiseData = _._addNoise(_.d.odeData, percentNoise)
            _._runAllAgorithms(noiseData, percentNoise)
        
        return _.jsonResults


######################################################################################################
#private helpers for noise generation
    def _addNoise(_, odeData: np.ndarray, noiseLevel: float):
        npr.seed(45638427)
        nD = np.empty_like(odeData)
        sig = _._getNoiseLevels(odeData, noiseLevel)
        for j in range(len(nD[0,:])):
            nD[:,j] = odeData[:,j] + npr.normal(loc=0.0, scale=sig[j], size=len(nD[:,j]))
        return nD 


    def _getNoiseLevels(_, data, noiseLevel: float):
        dMax = np.empty([len(data[0,:])])
        dMin = np.empty([len(data[0,:])])
        for i in range(len(data[0,:])):
            dMax[i] = max(data[:,i])
            dMin[i] = min(data[:,i])
                        
        return noiseLevel*(dMax - dMin)


######################################################################################################
#private helper
    def _runAllAgorithms(_, noiseData: np.ndarray, percentNoise: float):
        coordinateCount = len(_.d.odeData[0,:])
        for algo in SC.algos:
            if (algo == SC.DEFAULT_DIFF):
                model = pysindy.SINDy(feature_library=pysindy.PolynomialLibrary(degree=3)
                                      , feature_names=_._getFeatureNameList(coordinateCount))
            else:    
                model = pysindy.SINDy(feature_library=pysindy.PolynomialLibrary(degree=3)
                                      , feature_names=_._getFeatureNameList(coordinateCount)
                                      , differentiation_method=_._getDifferentiationMethod(algo))
            model.fit(noiseData, t=_.d.t)
            #model.print()                
            _._storeInJsonResults(algo, model.coefficients(), percentNoise)



    def _getFeatureNameList(_, iDegree: int):
        if iDegree == 2: return [SC.x_1, SC.x_2]
        elif iDegree == 3: return [SC.x_1, SC.x_2, SC.x_3]
        elif iDegree == 4: return [SC.x_1, SC.x_2, SC.x_3, SC.x_4]
        else:
            msg = "Invalid parametrisation of pysindynoisescan._getFeatureNameList"
            print(msg)
            raise Exception(msg)



    def _getDifferentiationMethod(_, algo: str):
        if algo == SC.FINITE_DIFF_DEFAULT: return FiniteDifference()
        if algo == SC.SPECTRAL_DERIVATIVE: return SpectralDerivative()        
        if algo == SC.SMOOTHED_FINITE_DIFF: return SmoothedFiniteDifference()        
        else:
            msg = "Invalid parametrisation of pysindynoisescan._getDifferentiationMethod"
            print(msg)
            raise Exception(msg)

######################################################################################################
#private helper for coversion to JSON
    def _storeInJsonResults(_, algo: str, res: np.ndarray, percentNoise: float):
        sr_all = {}
        for i in range(len(res[:,0])):
            sr = {}
            parNos = []
            parVals = []
            for j in range(len(res[i,:])):
                if abs(res[i,j]) > 0.00001:
                    parVals.append(res[i,j])
                    parNos.append(j)
            sr[C.parameterNumbers] = parNos
            sr[C.means] = parVals
            sr_all[i] = sr
            
        _.jsonResults[algo][round(percentNoise, 7)] = sr_all   
