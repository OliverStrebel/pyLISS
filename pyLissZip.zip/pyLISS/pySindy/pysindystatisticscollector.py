from liss_runner.constants import Constants as C


class  StatisticsCollector:
    def __init__(_,liss_result: dict):
        _.ref = liss_result[C.REFERENCE_DATA]
        _.config = liss_result[C.CONFIGURATION]
        _.res = liss_result
        algoKeyList = list(_.res.keys())
        algoKeyList.remove(C.REFERENCE_DATA)
        algoKeyList.remove(C.CONFIGURATION)
        _.algos = algoKeyList
        _.compKeyList = _.ref.keys()

        
    def getStatistics(_):
        res = {}
        for i in range(len(_.algos)):
            res[_.algos[i]] = _._getAlgoStatistics(_.res[_.algos[i]])
        return res


    def _getAlgoStatistics(_, algoResults: dict):
        stats = {}
        stats[C.correctModel] = _._correctModel(algoResults)
        stats[C.parameterValueStatistics] = _._meanParameterDeviation(algoResults, stats)
        return stats


######################################################################################################
#correct model statistics
    def _correctModel(_, algoResults: dict):
        correctModels = _._initCorrectModelMap(algoResults)
        for noiseLevel in algoResults.keys():
            for comp in _.compKeyList:
                if (len(algoResults[noiseLevel][comp]) > 0):
                    ok = _._matchResultWithReferenceData(algoResults[noiseLevel], comp)
                    correctModels[comp][C.noiseLevel].append(noiseLevel)
                    correctModels[comp][C.modelCorrect].append(ok)
            
        return correctModels


    def _initCorrectModelMap(_, algoResults: dict):
        modelMap = {}
        noiseLevel = list(algoResults.keys())[0]
        components = algoResults[noiseLevel]
        for comp in _.compKeyList:
            modelMap[comp] = {}
            modelMap[comp][C.noiseLevel] = list()
            modelMap[comp][C.modelCorrect] = list()
            
        return modelMap


    def _matchResultWithReferenceData(_, results: dict, comp):
        if results[comp][C.parameterNumbers] == _.ref[comp][C.parameterNumbers]:
            return 1.0
        else: return 0.0

######################################################################################################
#correct parameter statistics
    def _meanParameterDeviation(_, algoResults: dict, stats: dict):
        parMap = _._initParameterDeviationMap(algoResults)
        for comp in parMap.keys():
            if (comp in _.compKeyList):
                refParValues = _.ref[comp][C.parameterValues]
                noiseLevels = stats[C.correctModel][comp][C.noiseLevel]
                modelCorrectIndicator = stats[C.correctModel][comp][C.modelCorrect]

                for i in range(len(modelCorrectIndicator)):
                    if modelCorrectIndicator[i] > 0.0:
                        parMap[comp][C.noiseLevelWithCorrectModel].append(noiseLevels[i])
                        dev = _._getNormedDeviation(algoResults[noiseLevels[i]][comp], refParValues)
                        parMap[comp][C.meanParameterDeviation].append(dev)
        return parMap
        
        

    def _initParameterDeviationMap(_, algoResults: dict):
        parameterDeviationMap = {}
        noiseLevel = list(algoResults.keys())[0]
        for comp in _.compKeyList:
            parameterDeviationMap[comp] = {}
            parameterDeviationMap[comp][C.noiseLevelWithCorrectModel] = list()
            parameterDeviationMap[comp][C.meanParameterDeviation] = list()
            
        return parameterDeviationMap


    def _getNormedDeviation(_, parameterResults, refList):
        means = parameterResults[C.means]
        d = 0.0
        for i in range(len(refList)):
            d = d + abs((means[i] - refList[i])/refList[i])

        d = d/(1.0*len(refList))
        return d
    
