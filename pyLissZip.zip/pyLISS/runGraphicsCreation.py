import sys
import os
import json
import glob


from liss_runner.constants import Constants as C
from liss_runner.statisticscollector import StatisticsCollector
from liss_runner.statisticsevaluator import StatisticsEvaluator

import liss_runner.graph_success_percentage as gsp
import liss_runner.graph_parameter_deviation as gpd


dirs = ["Hamiltonian4D/", "Driven3D/", "Jerks/", "2D/", "3D/"]
#dirs = ["Hamiltonian4D/"]
statsData = []

#Transform all liss_result-files to liss_stats-files
for curDir in dirs:
    resultFileSelection = "data/" + curDir + "*.liss_result"
    for resultFileName in sorted(glob.glob(resultFileSelection)):
        statsCollector = StatisticsCollector(json.load(open(resultFileName, 'r')))
        baseName, extension = os.path.splitext(resultFileName)
        statsFileName = baseName + '.liss_stats'
        with open(statsFileName, 'w') as outfile:
            json.dump(statsCollector.getStatistics(), outfile, indent=4)


#Read all liss_stats-files
for curDir in dirs:
    statsFileSelection = "data/" + curDir + "*.liss_stats"
    for statsFileName in sorted(glob.glob(statsFileSelection)):
        print(statsFileName)
        statsFile = open(statsFileName, 'r')
        statsData.append(json.load(statsFile))


#Evaluate all liss_stats-files and write graphics
statsEvaluator = StatisticsEvaluator(statsData, C.algos)
stats = statsEvaluator.evaluateStatistics()
gsp.writeSuccessPercent(stats, C.algos)
gpd.writeParamDeviationPercent(stats, C.algos)


print('End program')

